#!/usr/bin/env bash
# Signiert Obsidian-Agent-Setup.exe unter Linux/macOS mit osslsigncode.
# Installation: apt install osslsigncode  bzw.  brew install osslsigncode
# Aufruf: ./signieren_linux.sh Obsidian-Agent-Setup.exe codesign.pfx
set -euo pipefail
EXE="$1"; PFX="$2"
read -r -s -p "Passwort der PFX-Datei: " PW; echo
osslsigncode sign -pkcs12 "$PFX" -pass "$PW" -n "Obsidian-Agent Setup" \
  -h sha256 -ts http://timestamp.digicert.com -in "$EXE" -out "${EXE%.exe}-signed.exe"
mv "${EXE%.exe}-signed.exe" "$EXE"
osslsigncode verify "$EXE"
sha256sum "$EXE" > "$(dirname "$EXE")/SHA256SUMS.txt"
echo "Signiert. SHA256SUMS.txt aktualisiert."
