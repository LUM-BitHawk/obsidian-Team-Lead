<#
  Signiert Obsidian-Agent-Setup.exe mit deinem Code-Signing-Zertifikat (Windows, signtool).
  Voraussetzung: Windows SDK (signtool.exe) und ein Code-Signing-Zertifikat
  (OV/EV von einer Zertifizierungsstelle oder Azure Trusted Signing).

  Variante A – Zertifikat als PFX-Datei:
    .\signieren_windows.ps1 -Exe .\Obsidian-Agent-Setup.exe -Pfx .\codesign.pfx
  Variante B – Zertifikat im Windows-Zertifikatspeicher bzw. auf USB-Token (EV):
    .\signieren_windows.ps1 -Exe .\Obsidian-Agent-Setup.exe -Thumbprint <SHA1-Fingerabdruck>
#>
param(
  [Parameter(Mandatory)] [string]$Exe,
  [string]$Pfx,
  [string]$Thumbprint,
  [string]$Zeitstempel = 'http://timestamp.digicert.com'
)
$signtool = Get-ChildItem "${env:ProgramFiles(x86)}\Windows Kits\10\bin\*\x64\signtool.exe" -ErrorAction SilentlyContinue |
  Sort-Object FullName -Descending | Select-Object -First 1
if (-not $signtool) { throw 'signtool.exe nicht gefunden. Bitte das Windows SDK installieren.' }
$sargs = @('sign', '/fd', 'SHA256', '/tr', $Zeitstempel, '/td', 'SHA256', '/d', 'Obsidian-Agent Setup')
if ($Pfx) {
  $pw = Read-Host 'Passwort der PFX-Datei' -AsSecureString
  $plain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($pw))
  $sargs += @('/f', $Pfx, '/p', $plain)
} elseif ($Thumbprint) {
  $sargs += @('/sha1', $Thumbprint)
} else { throw 'Bitte -Pfx oder -Thumbprint angeben.' }
& $signtool.FullName @args $Exe
if ($LASTEXITCODE -ne 0) { throw 'Signieren fehlgeschlagen.' }
& $signtool.FullName verify /pa /v $Exe
Get-FileHash $Exe -Algorithm SHA256 | ForEach-Object { "$($_.Hash.ToLower())  $(Split-Path $Exe -Leaf)" } |
  Set-Content (Join-Path (Split-Path $Exe) 'SHA256SUMS.txt') -Encoding ASCII
Write-Host 'Signiert und geprüft. SHA256SUMS.txt aktualisiert.' -ForegroundColor Green
