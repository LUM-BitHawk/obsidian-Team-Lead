# Installer signieren

Ohne Signatur warnt Windows beim ersten Start („Der Computer wurde durch Windows geschützt“) und macOS meldet einen „nicht verifizierten Entwickler“. Eine Signatur braucht ein Zertifikat, das auf dich oder deine Firma ausgestellt ist; es kann nicht durch Dritte ersetzt werden.

| Plattform | Was du brauchst | Skript |
|---|---|---|
| Windows | Code-Signing-Zertifikat (OV/EV) einer Zertifizierungsstelle oder **Azure Trusted Signing** | `signieren_windows.ps1` (signtool) oder `signieren_linux.sh` (osslsigncode) |
| macOS | Apple Developer Program, Zertifikat „Developer ID Installer“ | `signieren_mac.sh` (productsign + Notarisierung) |

Hinweise:
- Erst signieren, dann ins ZIP packen und die Prüfsumme (`SHA256SUMS.txt`) neu erzeugen – die Skripte machen das automatisch.
- Bei neuen OV-Zertifikaten baut Windows SmartScreen die Reputation erst mit der Zeit auf; die Warnung kann anfangs noch erscheinen. EV-Zertifikate und Azure Trusted Signing sind sofort vertrauenswürdig.
- Immer mit Zeitstempel signieren (in den Skripten enthalten), damit die Signatur auch nach Ablauf des Zertifikats gültig bleibt.
