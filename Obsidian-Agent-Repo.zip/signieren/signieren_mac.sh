#!/usr/bin/env bash
# Signiert und beglaubigt Obsidian-Agent.pkg (auf einem Mac mit Xcode-Kommandozeilenwerkzeugen).
# Voraussetzung: Apple Developer Program, Zertifikat "Developer ID Installer" im Schlüsselbund,
# App-spezifisches Passwort für notarytool.
# Aufruf: ./signieren_mac.sh Obsidian-Agent.pkg "Developer ID Installer: Firma (TEAMID)" apple-id@firma.ch TEAMID
set -euo pipefail
PKG="$1"; IDENT="$2"; APPLEID="$3"; TEAM="$4"
productsign --sign "$IDENT" "$PKG" "${PKG%.pkg}-signed.pkg"
mv "${PKG%.pkg}-signed.pkg" "$PKG"
xcrun notarytool submit "$PKG" --apple-id "$APPLEID" --team-id "$TEAM" --wait
xcrun stapler staple "$PKG"
pkgutil --check-signature "$PKG"
